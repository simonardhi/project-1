<?php

use CodeIgniter\Model;

class TrxOfferingModel extends Model {

    var $table = "trx_offering";
    var $primaryKey = "id";
    var $columns = ["name", "longitude", "latitude", "street_name", "price", "year_establish", "billboard_type"];

    public function index() {}
}