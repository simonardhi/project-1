<?php

use CodeIgniter\Model;

class EmployeeModel extends Model {

    var $table = "mst_employee";
    var $primaryKey = "id";
    var $columns = ["name", "address", "phone", "position", "dob", "npwp", "password"];

    public function index() {}
}