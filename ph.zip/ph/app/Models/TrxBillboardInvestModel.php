<?php

use CodeIgniter\Model;

class TrxBillboardInvestModel extends Model {

    var $table = "trx_billboard_invest";
    var $primaryKey = "id";
    var $columns = ["name", "longitude", "latitude", "street_name", "price", "year_establish", "billboard_type"];

    public function index() {}
}