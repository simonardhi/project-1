<?php

use CodeIgniter\Model;

class BillboardModel extends Model {

    var $table = "mst_billboard";
    var $primaryKey = "id";
    var $columns = ["name", "longitude", "latitude", "street_name", "price", "year_establish", "billboard_type"];

    public function index() {}
}