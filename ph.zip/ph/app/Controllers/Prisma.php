<?php namespace App\Controllers;

use App\Libraries\GroceryCrud;

class Prisma extends BaseController {

    public function index() {
        $crud = new GroceryCrud();
        $crud->setSubject('Employee');
        $crud->columns(['name', 'phone', 'position', 'dob', 'npwp']);
        $crud->callbackAddField('password', function ($fieldType, $fieldName) {
            return '<input class="form-control" name="' . $fieldName . '" type="password" value="">';
        });
        $crud->unsetEditFields(['password']);
        $crud->setTable('mst_employee');
        $output = $crud->render();
        return $this->_output($output);
    }

	public function employees() {
        $session = session();
        $crud = new GroceryCrud();
        $crud->setSubject('Employee');
        $crud->columns(['name', 'phone', 'position', 'dob', 'npwp']);
        $crud->callbackAddField('password', function ($fieldType, $fieldName) {
            return '<input class="form-control" name="' . $fieldName . '" type="password" value="">';
        });
        $crud->unsetEditFields(['password']);
        $crud->setTable('mst_employee');
        $output = $crud->render();
        if($session->get('isLogin') == 1) {
            return $this->_output($output);
        } else {
            $this->response->redirect(site_url('home'));
        }
	}

	public function billboards() {
        $crud = new GroceryCrud();
        $crud->setSubject('Billboards');
        $crud->setTable('mst_billboard');
        $crud->callbackColumn('price', function ($value) {
            return 'Rp. ' . number_format($value);
        });
        $output = $crud->render();

        return $this->_output($output);
    }

    public function investment () {
        $crud = new GroceryCrud();
        $crud->setSubject('Investment');
        $crud->setTable('trx_billboard_invest');
        $output = $crud->render();

        return $this->_output($output);
    }

    public function offerings() {
        $crud = new GroceryCrud();
        $crud->setSubject('Offerings');
        $crud->setRelation('employee_id','mst_employee','name');
        $crud->setRelation('billboard_id','mst_billboard','name');
        $crud->setTable('trx_offering');

        $output = $crud->render();

        return $this->_output($output);
    }

    public function employees_management()
    {
        $crud = new GroceryCrud();

        $crud->setTable('employees');
        $crud->setRelation('officeCode','offices','city');
        $crud->displayAs('officeCode','Office City');
        $crud->setSubject('Employee');

        $crud->requiredFields(['lastName']);

        $output = $crud->render();

        return $this->_output($output);
    }

    public function film_management()
    {
        $crud = new GroceryCrud();

        $crud->setTable('film');
        $crud->setRelationNtoN('actors', 'film_actor', 'actor', 'film_id', 'actor_id', 'fullname');
        $crud->setRelationNtoN('category', 'film_category', 'category', 'film_id', 'category_id', 'name');
        $crud->unsetColumns(['special_features','description','actors']);

        $crud->fields(['title', 'description', 'actors' ,  'category' ,'release_year', 'rental_duration', 'rental_rate', 'length', 'replacement_cost', 'rating', 'special_features']);

        $output = $crud->render();

        return $this->_output($output);
    }


    private function _output($output = null) {
        return view('apps', (array)$output);
    }


}
