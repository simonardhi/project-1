<?php namespace App\Controllers;

use App\Libraries\GroceryCrud;

class Api extends BaseController {

    public function index() {
    }

    public function login() {
        $db = db_connect();
        $session = session();

        $phone = $this->request->getPost('phone');
        $password = $this->request->getPost('password');

        $builder = $db->table('mst_employee');
        $builder->where('phone', $phone);
        $builder->where('password', $password);
        $data = $builder->get();
        if(!empty($data->getResult())) $session->set('isLogin', true);
        return $this->response->setJSON($data->getResultArray());
    }

    public function logout() {
        $session = session();
        $session->destroy();
        $this->response->redirect(site_url('home'));
    }
}